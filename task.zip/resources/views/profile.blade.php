<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Riku Portfolio</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://themesplay.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link rel="stylesheet" href="simple-line-icons/css/simple-line-icons.css">
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>

     
    <div id="custom-bootstrap-menu" class="navbar navbar-default " role="navigation">
    <div class="container-fluid">
        <div class="navbar-header"><a class="navbar-brand" href="/">Training Bootstrap</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-menubuilder">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav navbar-right">
                </li>
                <li><a href="/">Home</a>
                </li>
                <li><a href="profile">Profile</a>
                </li>
                <li><a href="contact">Contact </a>
                </li>
            </ul>
        </div>
    </div>
    </div> 

    <div class="row">
       <div class="col-md-4">
        <div class="poto">
           <h1>Riku Kiranatama</h1>  
           <img class="img-responsive img-circle poto-propil" src="img/riku.png">
        </div>
      </div> 

      <div class="col-md-8">
        <div class="data-diri">
            <table class="table table-striped">
                <tr>
                    <td class="bio-huruf">Nama</td>
                    <td class="bio-huruf">:</td>
                    <td class="bio-huruf">Riku Kranatama</td>
                </tr>
                <tr>
                    <td class="bio-huruf">Tempat, Tanggal Lahir </td>
                    <td class="bio-huruf">:</td>
                    <td class="bio-huruf">Bandung, 7 Oktober 1989</td>
                </tr>
                <tr>
                    <td class="bio-huruf">Jenis Kelamin</td>
                    <td class="bio-huruf">:</td>
                    <td class="bio-huruf">Pria</td>
                </tr>
                <tr>
                    <td class="bio-huruf">Alamat Domisili</td>
                    <td class="bio-huruf">:</td>
                    <td class="bio-huruf">Jl.Soekarno Hatta no.104</td>
                </tr>
            </table>
            
        </div>
      </div>

      </div>
    </div>
    
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script> 
<script src="js/portfolio/jquery.quicksand.js"></script>
<script src="js/portfolio/setting.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script> 

</script>
</body>
</html>